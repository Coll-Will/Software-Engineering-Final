<h2>Admin Warehouse Stock</h2>
<?php

include_once('warehouseConnection.php');
	$conn=connectDB();
	if(!$conn){
	echo "connecting failed, try again later!";
	die("failed on DB connection");
	}

	$query="SELECT * FROM stock";
		$result=$conn->query($query);
		if(!$result)
		{
			echo "query is not correct!";
			die("fatal error");
		}
		$rows=$result->num_rows;

		echo "<div class=\"row\">";

		for($i=0; $i<$rows; $i++)
		{
			$row=$result->fetch_array(MYSQLI_ASSOC);
			$imgname=$row['imgName'];
			$stock=$row['stock'];
			$itemName=$row['itemName'];
			echo "<div class=\"col col-sm-4\">";
			echo "<img src=\"./images/$imgname\" class=\"rounded\" alt=\"$imgname\">";
			echo "<h4> $itemName stock: $stock units</h4>";

		}

?>
