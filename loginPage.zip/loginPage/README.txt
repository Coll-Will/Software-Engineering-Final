-To run these files, locate and create the adminlogin and adminwarehouse databases. 
	-Run XAMPP, and go to http://localhost/loginPage
	-user:admin pass:admin

-To change the stock of a certain item, navigate to the bottom of the page.
	-Enter the ID of the item(located next to the item on the same page) and the changed
	quantity, and click submit. The columns will be updated on screen and in the database.