-To run these files, locate and create the adminlogin and adminwarehouse databases. 

-Run XAMPP, and go to http://localhost/loginPage

-user:admin pass:admin