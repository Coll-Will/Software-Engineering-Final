<?php

$conn = "";
    function connectDB()
    {
    $servername = "localhost:3306";
    $dbname = "adminWarehouse";
    $username = "root";
    $password = "";
     
    $conn = new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error) die("Fatal error on connecting to DB. ");

    return $conn;
    }
?>