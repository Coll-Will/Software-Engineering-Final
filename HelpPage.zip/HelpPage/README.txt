-To run this file open XAMPP and start APACHE. 

-save the file and go to http://localhost/HelpPage



-Things to work out in the future: how to but the animated buttons under another animated button to organize
the categories in a better fashion.